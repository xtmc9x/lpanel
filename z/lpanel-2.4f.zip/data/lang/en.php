<?php


//Ngônn ngu Vi nam

$chuyenngu = array(
'tt' => 'Control host via Lpanel 2.4',
'qmk' => 'Lost password',
'taikhoan' => 'User Name',
'matkhau' => 'Password',
'welcome'=>'Welcome you to come back!!!!',
'resetpass'=>'reset password',
'moidangnhap'=>'Enter info to login!',
'login'=>'Login',
'wait'=>'Please wait',
'trying'=>'trying',
'qmk'=>'Lost password',
'chuy'=>'<font color="red"><b>Note</b>:<br/>
					+ User, pass you enter a != A.<br/>
					+ You will ban if enter info correct.
					</font>',
'trangchu'=>'Home',
'congcu'=>'Tools',
'caidat'=>'Settings',
'thoat'=>'Exit',
'hihi'=>'<html>
		<body>
		<style>
		body { max-width: 700px; margin:0; margin:auto; padding:0px;}
		</style><center>
		<b align="center"><h1>This page not acept google index</h1>
		F5 (refresh page to go on) ...<br/>
		You will be secure if you turn on it....<br/>
		If you see it again, please turn on cookie on your browser ...</b>
		</center></body></html>',
'huongdancaidat'=>'Note:<br/>
	<ul>- Empty user and pass this lpanel is open access.</ul>
	<ul>- User name a!=A.</ul>
	<ul>- Question to recovery password longer 6 .</ul>
	<ul>- Check box change password to change password .</ul>',
'doicaidat'=>'Change settings',
'kieucaidat'=>'Type login',
'basic'=>'Basic',
'auth'=>'Auth (not to use)',
'ntaikhoan'=>'New User Login Name',
'nmatkhau'=>'New password',
'macdinhtool'=>'Default tools',
'tuychon'=>'Option',
'sodong'=>'Number lines',
'mailkhoiphuc'=>'E-mail to recovery password',
'cauhoi1'=>'Question 1',
'cauhoi2'=>'Question 2',
'dapan1'=>'Exercise 1',
'dapan2'=>'Exercise 2',
'baomat'=>'Secure',
'thoigiankhoa'=>'Time to ban',
'nhutruoc'=>'no change',
'gio'=>'hours',
'phut'=>'minutes',
'giay'=>'second',
'ngay'=>'days',
'sudungcauhoi'=>'Use it to lpanel',
'tuychinh'=>'Control',
'batbaove'=>'Turn on secure',
'chanbot'=>'Block Google Index Lpanel',
'doichude'=>'Change style',
'tatloi'=>'Off error',
'thaydoi'=>'Change',
'thanhcong'=>'Success...',
'thatbai'=>'Failed....',
'ngonngu'=>'Language',
'thoatra'=>'Your was log out ...',
'cgamana'=>'Control via gmanager',
'sqlql1'=>'Control sql via tool 1',
'sqlql2'=>'Control sql via tool 2',
'saoluusql'=>'Backup & Restore SQL',
'mahoa'=>'Encode',
'mahoamd5'=>'MD5 Encode',
'tonghop'=>'Other',
'chayphp'=>'Run PHP',
'phpinfo'=>'PHP info',
'chay'=>'Run',
'htmlcode'=>'Color html code',
'taocaidat'=>'Create install',
'kiemtra'=>'Test',
'gui'=>'Send',
'qlfile'=>'Control file',
'qlsql'=>'Control SQL',
'chinhsua'=>'Edit as text',
'xemnd'=>'View content',
'ktloi'=>'Check error',
'tai'=>'Download',
'xemma'=>'View Source',
'info'=>'Info',
'xoa'=>'Delete',
'mo'=>'Open',
'back'=>'Back',
''=>'',
''=>''
);

