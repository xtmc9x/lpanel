<?php


//Ngônn ngu Vi nam

$chuyenngu = array(
'tt' => 'Quản lí với Lpanel 2.4',
'qmk' => 'Quên mật khẩu',
'taikhoan' => 'Tên đăng nhập',
'matkhau' => 'Mật khẩu',
'welcome'=>'Chào mừng bạn đã trở lại !!!!',
'resetpass'=>'Đặt lại mật khẩu',
'moidangnhap'=>'Đăng nhập vào bảng điều khiển!',
'login'=>'Đăng nhập',
'wait'=>'Xin chờ',
'trying'=>'thử lại',
'chuy'=>'<font color="red"><b>Chú ý</b>:<br/>
					+ Tên, mật khẩu phân biệt chữ hoa/thường.<br/>
					+ Bạn sẽ bị khóa nếu nhập sai thông tin.
					</font>',
'trangchu'=>'Trang chủ',
'congcu'=>'Công cụ',
'caidat'=>'C.Đặt',
'thoat'=>'Thoát',
'hihi'=>'<html>
		<body>
		<style>
		body { max-width: 700px; margin:0; margin:auto; padding:0px;}
		</style><center>
		<b align="center"><h1>Đây là tường chặn bot index</h1>
		Nhấn tải lại để tiếp tục ...<br/>
		Chức năng này sẽ giúp bạn an toàn hơn khi bật....<br/>
		Nếu bạn nhìn thấy thông báo này liên tục mà không vào được, vui lòng kiểm tra cài đặt xem bạn đã bật cho phép cookie chưa  ...</b>
		</center></body></html>',
'huongdancaidat'=>'Thông tin cần phải biết:<br/>
	<ul>- Bỏ trống Tên truy cập và mật khẩu thì ai cũng có thể đăng nhập.</ul>
	<ul>- Tên truy cập và tên nick phân biệt Hoa/Thường.</ul>
	<ul>- Đáp án câu hỏi bí mật phải trên 6 kí tự, càng khó đoán càng tốt. Nó chỉ hoạt động chỉ khi bật "Sử dụng câu hỏi bí mật và phải có đáp án đầy đủ và hợp chuẩn (trên 6 kí tự).</ul>
	<ul>- Thời gian truy cập an toàn là thời gian dùng để chặn một ai đó cố gắng đăng nhập vào hệ thống.</ul>
	<ul>- Phương thức đăng nhập truyền thống sẽ an toàn hơn nhưng rát rối hơn.</ul>
	<ul>- Nếu không muốn đổi mật khẩu mới thì đừng check và ô trước ô nhập mật khẩu.</ul>',
'doicaidat'=>'Đổi cài đặt',
'kieucaidat'=>'Kiểu cài đặt',
'basic'=>'Cũ',
'auth'=>'Lạ (không nên dùng)',
'ntaikhoan'=>'Tài khoản mới',
'nmatkhau'=>'Mật khẩu mới',
'macdinhtool'=>'Công cụ mặc định',
'tuychon'=>'Tùy chọn',
'sodong'=>'Số dòng',
'mailkhoiphuc'=>'Mail để khôi phục (Chỉ dành cho những host hổ trợ mail(); )',
'cauhoi1'=>'Câu hỏi 1',
'cauhoi2'=>'Câu hỏi 2',
'dapan1'=>'Đáp án 1',
'dapan2'=>'Đáp án 2',
'baomat'=>'Bảo mật',
'thoigiankhoa'=>'Thời gian khóa',
'nhutruoc'=>'Như trước',
'gio'=>'giờ',
'phut'=>'phút',
'giay'=>'giây',
'ngay'=>'ngày',
'sudungcauhoi'=>'Sử dụng câu hỏi bí mật để khôi phục mật khẩu',
'tuychinh'=>'Tùy chỉnh',
'batbaove'=>'Bật bảo vệ',
'chanbot'=>'Chặn BOT',
'doichude'=>'Đổi chủ đề',
'tatloi'=>'Tắt thong báo lỗi',
'thaydoi'=>'Thay đổi',
'thanhcong'=>'Thành công...',
'thatbai'=>'Thất bại....',
'ngonngu'=>'Ngôn ngữ',
'thoatra'=>'Bạn đã thoát đăng nhập! Nếu bạn đăng nhập bằng hình thức 2 (Auth) thì thoát bằng cách đổi mật khẩu!',
'cgamana'=>'Quản lí bằng Gmanager',
'sqlql1'=>'Quản lí SQL 1',
'sqlql2'=>'Quản lí SQL 2',
'saoluusql'=>'Sao lưu CSDL',
'mahoa'=>'Mã hóa',
'mahoamd5'=>'Mã hóa md5',
'tonghop'=>'Công cụ khác',
'phpinfo'=>'Thông tin PHP',
'chayphp'=>'Chạy thử PHP',
'chay'=>'Chạy',
'htmlcode'=>'Mã màu html',
'taocaidat'=>'ọ cài đặt',
'kiemtra'=>'Kiểm tra',
'gui'=>'Gửi',
'qlfile'=>'Quản lí tệp',
'qlsql'=>'Quản lí SQL',
'chinhsua'=>'Chỉnh sửa',
'xemnd'=>'Xem nội dung',
'ktloi'=>'Kiểm tra lỗi',
'tai'=>'Tải về',
'xemma'=>'Xem mã',
'info'=>'Thông tin',
'xoa'=>'Xóa bỏ',
'mo'=>'Mở thư mục',
'back'=>'Quay lại',
''=>'',
''=>''
);

