<?php

@ob_clean(); phpinfo(); exit;


