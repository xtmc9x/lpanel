<?php

require_once('../bootstrap.php');

echo Registry::get('top');


echo Registry::get('foot');
