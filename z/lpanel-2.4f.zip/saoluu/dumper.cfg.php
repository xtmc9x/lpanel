<?php
$this->SET = array(
'last_action' => '1',
'last_db_backup' => '',
'tables' => '',
'comp_method' => '2',
'comp_level' => '7',
'last_db_restore' => '2hi',
)
?>